package maths;

import java.math.BigInteger;

public class CountOfDigits {
	public static void main(String[] args) {
		System.out.println(digitsInFactorial(10));
	}
	/*public static int  digitsInFactorial(int N)
    {
        //Your code here
        BigInteger n=factorial(new BigInteger(N+""));
        int c=0;
        
        while(!n.equals(BigInteger.ZERO)){
            c++;
            n=n.divide(BigInteger.TEN);
        }
        return n.toString().length();
    }*/
	public static int digitsInFactorial(int N){
		/*if (n < 0) 
			return 0;

			// base case 
		if (n <= 1) 
			return 1;
		double digits = 0; 
		for (int i=2; i<=n; i++) 
		digits += Math.log10(i);

		return (int)Math.floor(digits)+1;*/
		
		int count=0;
		for(int i=2;i<=N;i++){
			double c= Math.sqrt(i);
			double d=c-(int)c;
			if(d==0.0){
				int cr=0;
				for(int j=1;j<=c;j++){
					if(d%j==0){
						cr++;
					}
				}
				if(cr==2){
					count++;
				}
			}
		}
		
        return count;
		
	}
    public static BigInteger factorial(BigInteger N){
        return N.equals(BigInteger.ZERO)?BigInteger.ONE:N.multiply(factorial(N.subtract(BigInteger.ONE)));
    }
}
