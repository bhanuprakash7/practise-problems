
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

// Class name should be "Source",
// otherwise solution won't be accepted
public class Source {
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        
        // Declare the variable
        int a;
        
        // Read the variable from STDIN
        a = in.nextInt();
        int[] arr=new int[a];
        for(int i:arr){
            arr[i]=in.nextInt();
        }
        System.out.println("start");
        for(int i=0;i<arr.length;i++){
            int data=1;
            for(int j=0;j<arr.length;j++){
                if(i!=j){
                    data*=arr[j];
                }
            }
            System.out.println(data);
        }
        // Output the variable to STDOUT
       // System.out.println(a);
   }
}

