public class DoSelect extends Thread
{
    private int co;
    @Override
    public void run()
    {
        synchronized(this)
        {
            for(int i = 0; i < 100000; i++)
                co++;
            this.notifyAll();
            System.out.println("Completed Counting....");
        }
    }
    public static void main(String[] args) throws InterruptedException
    {
        DoSelect ds = new DoSelect();
        ds.start();
        Thread.sleep(10000);
        System.out.println("Waiting to get End....");
        synchronized(ds)
        {
            ds.wait();
        }
        System.out.println(ds.co);
    }
}