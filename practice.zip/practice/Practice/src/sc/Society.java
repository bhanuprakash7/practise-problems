package sc;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Society {
	public static void permutate(char[] original,char[] result,int[] count,int size,int limit,Map<String,Integer> list){
		
		if(limit==size){
			StringBuilder sb=new StringBuilder("");
			int j=0;
			int n=size;
			for(int i=size-1;i>=0;i--){
				if(result[i]=='1'){
					sb.append(result[i]);
					j+=Math.pow(2, size-(n));
				}
				else{
					sb.append(result[i]);
				}
				n--;
			}
			String s=sb.reverse().toString();
			if(!list.containsKey(s)){
				list.put(s, j);
			}
		}
		else{
			for(int i=0;i<size;i++){
				if(count[i]==-1){
					continue;
				}
				else{
					count[i]--;
					result[limit]=original[i];
					permutate(original,result,count,size,limit+1,list);
					count[i]++;
				}
			}
		}
	}
	public static long doPer(int n,Map<String,Integer> list){
		StringBuilder s=new StringBuilder("");
		while(n>0){
			int i=n%2;
			s.append(i);
			n=n/2;
		}
		s=s.reverse();
		int k=s.length();
		char[] original=s.toString().toCharArray();
		char[] result=new char[k];
		int[] count=new int[k];
		
		
		permutate(original,result,count,k,0,list);
		long j=0;
		Iterator<Map.Entry<String,Integer>> itr=list.entrySet().iterator();
		while(itr.hasNext()){
			Map.Entry<String,Integer> e=(Map.Entry<String,Integer>)itr.next();
			j+=e.getValue();
		}
		
		return j;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		while(t-->0){
			int n=sc.nextInt();
			Map<String,Integer> list=new HashMap<String,Integer>();
			System.out.println(doPer(n,list));
		}
		
	}
}
