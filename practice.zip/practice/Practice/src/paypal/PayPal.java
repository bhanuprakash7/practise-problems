package paypal;

import java.math.BigInteger;
import java.util.Scanner;

public class PayPal 
{
	public static void doProcess(StringBuilder s){
		int count=0;
		for(int i=0;i<s.length();i++){
			for(int j=i+1;j<=s.length();j++){
				String str=s.substring(i,j);
				char []ch=str.toCharArray();
				
				int c=0;
				
				for(int k=ch.length-1;k>=0;k--){
					
					if(c++%2==0){
						continue;
					}
					else{
						int p=Integer.parseInt(""+ch[k]);
						p=p*2;
						int d=0;
						if(p>=10){
							while(p>0){
								d+=p%10;
								p=p/10;
							}
						}
						else{
							d=p;
						}
						ch[k]=(char)(d+'0');
					}
				}
				int val=0;
				for(char ca:ch){
					val+=Integer.parseInt(""+ca);
				}
				if(val%10==0){
					count++;
				}
			}
		}
		System.out.println(count);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		while(t-->0){
			int l=sc.nextInt();
			StringBuilder s=new StringBuilder("");
			s=s.append(sc.next());
			doProcess(s);
			
		}
	}
}
