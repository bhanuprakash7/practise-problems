package search;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Peak {
	public static int peakElement(int[] a,int n)
    {
		
       //add code here.
	       int start=0;
	       int end=n-1;
	       int mid=0;
	       while(start<=end){
	    	   mid=(start+end)/2;
	    	   if(mid==0){
	    		   mid=1;
	    		   break;
	    	   }
	    	   else if(mid==n-1){
	    		   mid=1;
	    		   break;
	    	   }
	    	   else if(a[mid]<a[mid+1]){
	    		   start=mid+1;
	    	   }
	    	   else{
	    		   end=mid;
	    	   }
	       }
	       return mid;
    }
	public static void main(String[] args) {
		int[] a={1,2,3};
		int n=3;
		System.out.println(peakElement(a,n));
	}
}
