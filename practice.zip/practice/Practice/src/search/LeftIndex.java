package search;

public class LeftIndex {
	static int leftIndex(int sizeOfArray, int arr[], int elementToSearch)
    {
       
       // Your code here
       int start=0;
       int end=sizeOfArray-1;
       int mid=-1;
       int c=0;
       while(start<=end){
    	   mid=(start+(end-start))/2;
    	   if(arr[mid]<=elementToSearch){
    		   start=mid+1;
    		   for(int i=start;i<end;i++){
    			   if(arr[i]==elementToSearch){
    				   mid=i;
    				   c++;
    				   break;
    			   }
    		   }
    		   break;
    	   }
    	   else{
    		   end=mid;
    		   for(int i=start;i<end;i++){
    			   if(arr[i]==elementToSearch){
    				   mid=i;
    				   c++;
    				   break;
    			   }
    		   }
    		   break;
    	   }
       }
       /*while(start<=end){
           mid=(start+(end-start))/2;
           if(start==end){
               mid=end;
               break;
           }
           if(arr[mid]==elementToSearch&&arr[mid-1]!=elementToSearch){
               break;
           }
           else if(arr[mid]==elementToSearch&&arr[mid-1]==elementToSearch){
               end=mid-1;
           }
           else if(arr[mid]<=elementToSearch){
               start=mid+1;
           }
           else{
               end=mid;
           }
       }*/
       return c==0?-1:mid;
   
    }
	public static void main(String[] args) {
		int []a={98765, 99300, 99455, 99500, 99555};
		int n=5;
		int x=99555;
		System.out.println(leftIndex(n,a,x));
	}
}
