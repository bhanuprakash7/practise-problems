package search;

public class Majority {
	static int majorityElement(int a[], int size)
    {
        // your code here
        int c=0;
        for(int i=0;i<size;i++){
            c=0;
            for(int j=0;j<size;j++){
                if(a[i]==a[j]){
                    c++;
                }
            }
            if(c>(size/2)){
                break;
            }
            
        }
        if(c==1){
            return -1;
        }
        else{
            return c>=size/2?c:-1;
        }
        
    }
	public static void main(String[] args) {
		int n=3;
		int[] arr={1,2,3};
		System.out.println(majorityElement(arr,n));
	}
}
