package search;

public class FloorSearch {
	static int findFloor(long arr[], int left, int right, long x)
    {
           int start=left;
	       int end=right;
	       int mid=0;
	       int j=-1;
	       while(start<=end){
	    	   mid=(start+end)/2;
	    	   if(mid==0){
		    		  return -1;
		    	   }
	    	   else if(mid==right){
	    		   return mid;
	    	   }
	    	   else if((arr[mid]==x)||(arr[mid]<x&&arr[mid+1]>=x)||(arr[mid]>x&&arr[mid-1]<=x)){
	    		   if(arr[mid+1]==x){
	    		       j=mid+1;
	    		      
	    		   }
	    		   else if(arr[mid-1]==x){
	    		       j=mid-1;
	    		       
	    		   }
	    		   else{
	    			   j=mid;
	    		   }
	    		   break;
	    	   }
	    	   else if(arr[mid]>x){
	    	       end=mid;
	    	   }
	    	   else{
	    		   start=mid+1;
	    	   }
	       }
	       return j;
    }
	public static void main(String[] args) {
		long []l={1, 2, 8, 10, 11, 12, 19};
		int n=7;
		int x=5;
		int s=0;
		int e=l.length-1;
		System.out.println(findFloor(l,s,e,x));
	}
}
