package search;

public class SquareRoot {
	 static long floorSqrt(long x)
	 {
		// Your code here
		 long start=0;
		 long end=x;
		 double ans=0.0;
		 long mid=0;
		 while(start<=end){
			  mid=(start+(end-start))/2;
			 if(mid*mid==x||(mid*mid<x&&(mid+1)*(mid+1)>x)){
				 return mid;
			 }
			 if(mid*mid<x){
				 start=mid+1;
			 }
			 else{
				 end=mid-1;
			 }
		 }
		 return mid;
		
	 }
	 public static void main(String[] args) {
		 System.out.println(floorSqrt(5));
	}
}
