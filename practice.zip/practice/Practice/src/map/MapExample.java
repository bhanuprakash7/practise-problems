package map;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class MapExample {
	public static void main(String[] args) {
		Map<Character,Integer> m=new TreeMap<Character,Integer>();
		m.put('a', 1);
		m.put('b', 2);
		Set<Character> s=m.keySet();
		Iterator<Character> itr=s.iterator();
		while(itr.hasNext()){
			Character c=(Character)itr.next();
			Integer i=m.get(c);
		}
	}
}
