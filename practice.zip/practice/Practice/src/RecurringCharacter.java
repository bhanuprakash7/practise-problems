import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RecurringCharacter 
{
	public static void main(String[] args) {
		String s="abcbc";
		Map m=new HashMap();
		boolean b=false;
		for(int i=0;i<s.length();i++)
		{
			if(m.containsKey(s.charAt(i)))
			{
				System.out.println(s.charAt(i));
				b=true;
				break;
			}
			else
			{
				m.put(s.charAt(i), 1);
			}
		}
		if(!b)
		{
			System.out.println("null");
		}
	
		
	}
}
