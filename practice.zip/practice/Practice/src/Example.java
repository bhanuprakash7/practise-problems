class Node{
	String name;
	int a;
}
public class Example {
	public static void main(String[] args) {
		Node node= new Node();
		node.name="abc";
		node.a=10;
		Node node1=node;
		node1.a=20;
		node=null;
		Node node2=node1;
		System.out.println(node1.name);
	}
}
