import java.util.Arrays;
import java.util.Scanner;


public class Solution1 
{
	 static void minimumBribes(int[] q) {
	        int n=q.length;
	        int[] p=new int[q.length];
	        p=q.clone();
	        int a[]=new int[q.length];
	        Arrays.sort(p);
	        int count=0;
	        boolean b=false;
	        for(int i=0;i<q.length;i++)
	        {
	        	a[i]=q[i]-p[i];
	        	/*if(q[i]-p[i]==1)
	        	{
	        		count++;
	        		i++;
	        	}
	        	else if(q[i]-p[i]==2)
	        	{
	        		count+=2;
	        		i+=2;
	        	}
	        	else if(q[i]-p[i]>2)
	        	{
	        		System.out.println("Too chaotic");
	        		b=true;
	        		count=0;
	        		break;
	        	}*/
	        }
	       /* if(!b)
	        {
	        	
	        	System.out.println(count);
	        }*/
	        int max=0;
	       
	        for(int i=0;i<a.length;i++)
	        {
	        	if(a[i]>max)
	        	{
	        		max=a[i];
	        		if(max>2)
	    	        {
	    	        	System.out.println("Too chaos");
	    	        	return;
	    	        }
	        	}
	        }
	        for(int i=0;i<a.length;i++)
	        {
	        	if(a[i]>0)
	        	{
	        		count+=a[i];
	        	}
	        }
	        System.out.println(count);

	    }

	    private static final Scanner scanner = new Scanner(System.in);

	    public static void main(String[] args) {
	        
	    		int []q={2,5,1,3,4};
	            minimumBribes(q);
	        
	    }
}
