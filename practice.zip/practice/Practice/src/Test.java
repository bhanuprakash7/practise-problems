
class D{
	 void go(){
		System.out.println("In D");
	}
}
class E extends D{
	 void go(){
		System.out.println("In E");
		super.go();
	}
}
/*class Abc{
	int a=10;
	void go(){
		System.out.println("in abc");
	}
}*/
public class Test extends  E  {
	int a=20;
	public void go(){
		System.out.println("in test");
		
	}
	public static void main(String[] args) {
		D t=new Test();
		
		t.go();
	}
}
