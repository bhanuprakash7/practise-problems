import java.util.Scanner;


public class Matrix 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		Scanner scr=new Scanner(System.in).useDelimiter(",");
		int x=0,y=0;
		while(scr.hasNext()){
			String[] ar=scr.next().split(" ");
			char direction=ar[0].charAt(0);
			int val=Integer.parseInt(ar[1]);
			if(direction=='N'){
				y+=val;
			}
			else if(direction=='S'){
				y-=val;
			}
			else if(direction=='E'){
				x+=val;
			}
			else{
				x-=val;
			}
		}
		int fin=(int) Math.sqrt((double)(Math.abs(a-x)*Math.abs(a-x))+(Math.abs(b-y)*Math.abs(b-y)));
		System.out.println(x+" "+y);
		System.out.println(fin);
		
	}
}
