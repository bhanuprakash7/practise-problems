
public class Demo {

	public static void main(String[] args){
		double i=1.1;
		double o;
		double q;
		o=1.5;
		o=2.5;
		char c='a';
		String s=null;
		boolean b=true;
		short s1=87;
		long a=234567890;
	}


}
