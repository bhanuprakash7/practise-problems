import java.math.BigInteger;
import java.util.Scanner;


public class ITC {
	public static void doProcess(BigInteger n){
		StringBuilder s=new StringBuilder("");
		BigInteger two=new BigInteger("2");
		while(true){
			s.append(n.remainder(two));
			n=n.divide(two);
			if(n.compareTo(BigInteger.ZERO)==0){
				break;
			}
		}
		s=s.reverse();
		int c=0;
		for(int i=0;i<s.length();i++){
			for(int j=i+1;j<=s.length();j++){
				StringBuilder s1=new StringBuilder(s.substring(i, j));
				if(!s1.equals(s)){
					int c1=0;
					for(int k=0;k<s1.length();k++){
						if('1'==s1.charAt(k)){
							c1++;
						}
					}
					if(c1%2!=0){
						c++;
					}
				}
			}
		}
		System.out.println(c);
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		while(t-->0){
			BigInteger n=sc.nextBigInteger();
			doProcess(n);
		}
		sc.close();
	}
}
