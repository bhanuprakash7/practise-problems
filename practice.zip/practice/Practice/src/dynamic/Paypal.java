package dynamic;

public class Paypal {

}
