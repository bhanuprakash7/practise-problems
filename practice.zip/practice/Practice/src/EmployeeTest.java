class Employees{
	int a;
	String s;
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}
	public Employees(){
		
	}
	public Employees(int a, String s) {
		super();
		this.a = a;
		this.s = s;
	}
	public String toString(){
		return this.a+" "+this.s;
	}
}
public class EmployeeTest {
	public static void main(String[] args) {
	
	Employees e=new Employees();
	Employees f=new Employees();
	e.a=1;
	e.s="abc";
	f.a=1;
	f.s="def";
	System.out.println(e);
	System.out.println(f);
	}
	
}
