
public class Demo1 
{
	static int w;
	 int q=1+w;
	
	public static void main(String[] args) {
		System.out.println(w);
		System.out.println(q);
		System.out.println("out main..");
	}
	/*public static void move(int i)
	{
		int j=0;
		int b=1+j;
		System.out.println(i);
		int c=0;
		System.out.println(c);
	}*/
	
	/*public static void move(int hi){
		System.out.println("move south");
	}*/
}

