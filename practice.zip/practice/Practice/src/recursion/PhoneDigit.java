package recursion;

public class PhoneDigit
{
    static void possibleWords(int a[], int N)
    {
        // your code here  
        char[] ch=new char[N];
        String[] array={"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
        int index=0;
        words(N,ch,array,0, index,a);
        System.out.println();
        words(N,"",array,0, index,a);
    }
    static void words(int N,String str,String[] array,int count,int index,int a[]){
    	 if(str.length()==N){
             System.out.print(str+" ");
            
         }
         else{
         	String s=array[a[index]];
             for(int i=0;i<s.length();i++){
                 words(N,str+s.charAt(i),array,count,index+1,a);
                 
             }
         }
    }
    static void words(int N,char[] ch,String[] array,int count,int index,int a[]){
        if(count==N){
            for(int i=0;i<ch.length;i++){
            	System.out.print(ch[i]);
            }
            System.out.print(" ");
        }
        else{
        	String s=array[a[index]];
            for(int i=0;i<s.length();i++){
                ch[index]=s.charAt(i);
                count++;
                words(N,ch,array,count,index+1,a);
                count--;
                ch[index]=0;
            }
        }
    }
    public static void main(String[] args) {
		int[] a={3,4,5};
		int N=a.length;
		possibleWords(a,N);
	}
}
