package recursion;

public class KnightTour 
{
	public static boolean knight(int[][] board,int[][] visited,int steps,int row,int col,int[] rows,int[] cols){
		if(steps==63){
			for(int i=0;i<8;i++){
				for(int j=0;j<8;j++){
					System.out.print(visited[i][j]+" ");
				}
				System.out.println();
			}
			return true;
		}
		else{
			for(int index=0;index<rows.length;index++){
				int newRow=row+rows[index];
				int newCol=col+cols[index];
				if(valid(newRow,newCol,visited)){
					steps++;
					visited[newRow][newCol]=steps;
					if(knight(board,visited,steps,newRow,newCol,rows,cols)){
						return true;
					}
					steps--;
					visited[newRow][newCol]=-1;
					
				}
			}
		}
		return false;
	}
	public static boolean valid(int row,int col,int[][] visited){
		if(row>=0&&row<8&&col>=0&&col<8&&visited[row][col]==-1){
			return true;
		}
		else{
			return false;
		}
	}
	public static void main(String[] args) {
		int[][] board=new int[8][8];
		for(int i=0;i<board.length;i++){
			for(int j=0;j<board[i].length;j++){
				//System.out.print(1+" ");
				board[i][j]=0;
			}
			
		}
		int[][] visited=new int[8][8];
		for(int i=0;i<visited.length;i++){
			for(int j=0;j<visited[i].length;j++){
				visited[i][j]=-1;
			}
		}
		visited[0][0]=0;
		int[] rows = { -2,-1,-2,-1,1,2,2,1 };
		int[] cols = { -1,-2,1,2,2,1,-1,-2 };
		knight(board,visited,0,0,0,rows,cols);
	}
}
