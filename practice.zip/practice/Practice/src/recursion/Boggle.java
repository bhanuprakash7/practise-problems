package recursion;

import java.util.ArrayList;
import java.util.List;

public class Boggle 
{
	public static void mazes(char[][] maze,int[][] visited,List<String> dictionary,int[] rows,int[] cols,int row,int col,String word){
		//System.out.println(word);
		if(dictionary.contains(word)){
			
			System.out.println(word);
			
		}
		if(word.length()==maze.length*maze.length){
			return;
		}	
		for(int index=0;index<rows.length;index++){
			int newRow=row+rows[index];
			int newCol=col+cols[index];
			if(valid(visited,newRow,newCol)){
				visited[newRow][newCol]=1;
				mazes(maze,visited,dictionary,rows,cols,newRow,newCol,word+maze[newRow][newCol]);
				visited[newRow][newCol]=0;
				
			}
		}
		
	}
	public static boolean valid(int[][] visited,int newRow,int newCol){
		if(newRow>=0&&newRow<3&&newCol>=0&&newCol<3&&visited[newRow][newCol]==0){
			return true;
		}
		else{
			return false;
		}
	}
	public static void main(String[] args) {
		char[][] maze={{'G','I','Z'},
				       {'U','E','K'},
				       {'Q','S','E'}};
		int[][] visited={{0,0,0},
	             {0,0,0},
	             {0,0,0}};
		
		String word="";
		List<String> dictionary=new ArrayList<String>();
		dictionary.add("GEEKS");
		dictionary.add("FOR");
		dictionary.add("NO");
		dictionary.add("QUIZ");
		
		int[] row = { -1, -1, -1, 0, 1, 1, 1, 0 };
		int[] col = { -1, 0, 1, 1, 1, 0, -1, -1 };
		
			
			for(int r=0;r<3;r++){
				for(int c=0;c<3;c++){
					
					visited[r][c]=1;
					mazes(maze,visited,dictionary,row,col,r,c,word+maze[r][c]);
					
					visited[r][c]=0;
				}
			}	
		
	}
}
