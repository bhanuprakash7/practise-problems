package recursion;

public class AllSubStrings 
{
	public static void subStrings(String s,String curr,int i){
		if(i==s.length()){
			System.out.println(curr);
			return;
		}
		subStrings(s,curr,i+1);
		subStrings(s, curr+s.charAt(i), i+1);
	}
	
	public static void main(String[] args) {
		String s="ABC";
		subStrings(s,"",0);
	}
}
