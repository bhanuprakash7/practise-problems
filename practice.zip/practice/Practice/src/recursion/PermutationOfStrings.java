package recursion;

public class PermutationOfStrings 
{
	public static void permutate(char[] ch,int limit,int[] count,char[] result)
	{
		if(limit==result.length){
			for(char c:result){
				System.out.print(c);
			}
			System.out.println();
		}
		for(int i=0;i<count.length;i++)
		{
			if(count[i]==0){
				continue;
			}
			else{
				count[i]--;
				result[limit]=ch[i];
				permutate(ch,limit+1,count,result);
				count[i]++;
			}
		}
	}
	public static void main(String[] args) {
		String s="aabc";
		char[] ch=s.toCharArray();
		int[] charCount=new int[ch.length];
		int size=s.length();
		for(int i=0;i<size;i++){
			charCount[i]=1;
		}
		char[] result=new char[ch.length];
		permutate(ch,0,charCount,result);
	}
}
