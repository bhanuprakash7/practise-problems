package recursion;

public class RatInMaze 
{
	public static void maze(int[] rows,int[] cols,int[][] maze,int[][] visited,int row,int col,int desRow,int desCol,int move){
		if(row==desRow&&col==desCol){
			for(int i=0;i<4;i++){
				for(int j=0;j<4;j++){
					System.out.print(visited[i][j]+" ");
				}
				System.out.println();
			}
			System.out.println();
			System.out.println();
		}else{
			for(int i=0;i<rows.length;i++){
				int newRow=row+rows[i];
				int newCol=col+cols[i];
				if(checkValidMove(newRow,newCol,maze,visited)){
					move++;
					visited[newRow][newCol]=move;
					maze(rows,cols,maze,visited,newRow,newCol,desRow,desCol,move);
					visited[newRow][newCol]=0;
					move--; 
				}
			}	
		}
	}
	public static boolean checkValidMove(int row,int col,int[][] maze,int[][] visited){
		if(row>=0&&row<4&&col>=0&&col<4&&maze[row][col]==1&&visited[row][col]==0){
			return true;
		}
		else{
			return false;
		}
	}
	public static void main(String[] args) {
		int[] rows={0,-1,1,0};
		int[] cols={-1,0,0,1};
		
		int[][] maze={{1,1,0,1},
					  {0,1,1,1},
					  {0,1,0,1},
					  {0,1,1,1}};
		int[][] visited={{1,0,0,0},
				             {0,0,0,0},
				             {0,0,0,0},
				             {0,0,0,0}};
		int move=1;
		maze(rows,cols,maze,visited,0,0,3,3,move);
	}
}
