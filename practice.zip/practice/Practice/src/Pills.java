import java.util.Scanner;


public class Pills 
{
	static char o='o',x='x',b='b',r='r';
	
	public static void doFo(char[][] a,int i,int j){
		
		for(int k=0;k<i-1;k++){
			for(int l=0;l<j-1;l++){
				if(a[k][l]==r){
					if(a[k][l+1]==x){
						a[k][l+1]=o;
					}
					if(a[k+1][l+1]==x){
						a[k+1][l+1]=o;
					}
					if(a[k+1][l]==x){
						a[k+1][l]=o;
					}
				}
				if(a[k][l]==b){
					if(a[k][l+1]==x){
						a[k][l+1]=o;
					}
					if(a[k+1][l]==x){
						a[k+1][l]=o;
					}
				}
			}
		}
	}
	
	public static void doFo1(char[][] a,int i,int j){
		for(int k=0;k<i-1;k++){
			for(int l=j-1;l>0;l--){
				if(a[k][l]==r){
					if(a[k][l-1]==x){
						a[k][l-1]=o;
					}
					if(a[k+1][l-1]==x){
						a[k+1][l-1]=o;
					}
					if(a[k+1][l]==x){
						a[k+1][l]=o;
					}
				}
				if(a[k][l]==b){
					if(a[k][l-1]==x){
						a[k][l-1]=o;
					}
					if(a[k+1][l]==x){
						a[k+1][l]=o;
					}
				}
			}
		}
	}
	
	public static void doRe1(char[][] a,int i,int j){
		for(int k=i-1;k>0;k--){
			for(int l=0;l<j-1;l++){
				if(a[k][l]==r){
					if(a[k][l+1]==x){
						a[k][l+1]=o;
					}
					if(a[k-1][l+1]==x){
						a[k-1][l+1]=o;
					}
					if(a[k-1][l]==x){
						a[k-1][l]=o;
					}
				}
				if(a[k][l]==b){
					if(a[k][l+1]==x){
						a[k][l+1]=o;
					}
					if(a[k-1][l]==x){
						a[k-1][l]=o;
					}
				}
			}
		}
	}
	
	public static void doRe(char[][] a,int i,int j){
		for(int k=i-1;k>0;k--){
			for(int l=j-1;l>0;l--){
				if(a[k][l]==r){
					if(a[k][l-1]==x){
						a[k][l-1]=o;
					}
					if(a[k-1][l-1]==x){
						a[k-1][l-1]=o;
					}
					if(a[k-1][l]==x){
						a[k-1][l]=o;
					}
				}
				if(a[k][l]==b){
					if(a[k][l-1]==x){
						a[k][l-1]='o';
					}
					if(a[k-1][l]==x){
						a[k-1][l]=o;
					}
				}
			}
		}
	}
	
	public static void doTask(char[][] a,int m, int n){
		int c=0;
		for(int i=0;i<m;i++){
			for(int j=0;j<n;j++){
				if(a[i][j]==x){
					c++;
				}
			}
		}
		if(c==0){
			System.out.println(c);
			return;
		}
		if(c==m*n){
			System.out.println(c);
			return;
		}
		if(m==1||n==1){
			if(m==1){
				for(int i=0;i<n;i++){
					if(i==0&&(a[0][i]==b||a[0][i]==r)){
						if(a[0][i+1]==x){
							a[0][i+1]=o;
						}	
					}
					else if(i==n-1&&(a[0][i]==b||a[0][i]==r)){
						if(a[0][i-1]==x){
							a[0][i-1]=o;
						}
					}
					else{
						if(a[0][i]==b||a[0][i]==r){
							if(a[0][i-1]==x){
								a[0][i-1]=o;
							}
							if(a[0][i+1]==x){
								a[0][i+1]=o;
							}
						}
					}
				}
			}
			else{
				for(int i=0;i<m;i++){
					if(i==0&&(a[i][0]==b||a[i][0]==r)){
						if(a[i+1][0]==x){
							a[i+1][0]=o;
						}	
					}
					else if(i==m-1&&(a[i][0]==b||a[i][0]==r)){
						if(a[i-1][0]==x){
							a[i-1][0]=o;
						}
					}
					else{
						if(a[i][0]==b||a[i][0]=='r'){
							if(a[i-1][0]==x){
								a[i-1][0]=o;
							}
							if(a[i+1][0]==x){
								a[i+1][0]=o;
							}
						}
					}
				}
			}	
		}
		else{
			doFo(a,m,n);
			doRe(a,m,n);
			doFo1(a,m,n);
			doRe1(a,m,n);
			
		}
		int c1=0;
		for(int i=0;i<m;i++){
			for(int j=0;j<n;j++){
				if(a[i][j]==x){
					c1++;
				}
			}
		}
		System.out.println(c1);	
	}
	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int t=s.nextInt();
		while(t-->0){
			int m=s.nextInt();
			int n=s.nextInt();
			char[][] a=new char[m][n];
			for(int i=0;i<m;i++){
				 String d = "";
			        if (s.hasNext()) {  
			            d = s.next();
			        } else {
			            break;
			        }
				for(int j=0;j<n;j++){
					a[i][j]=d.charAt(j);
					
				}
			}
			doTask(a,m,n);
		}
	}
}
