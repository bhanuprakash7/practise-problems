
public class Employee1
{
	static String companyName="DXC Technology";
	static String branchName="EC1";
	int id;
	int age;
	String name;
	int height;
	public Employee1(int id,int age, String name,int height){
		this.id=id;
		this.age=age;
		this.name=name;
		this.height=height;
	}
	public Employee1(int id,int age, String name){
		this.id=id;
		this.age=age;
		this.name=name;
	}
	public static void add(int a,int b){
		
	}
	public static void add(int i, int j,int k){
		
	}
	public static void main(String[] args) {
		Employee1 kiran=new Employee1(123,22,"kiran",5);
		Employee1 bhanu=new Employee1(125,25,"prakash",6);
		System.out.println(kiran.id+" ,"+kiran.age+" "+kiran.companyName);
		System.out.println(bhanu.id);
	}
	public Employee1(){
		
	}
}
