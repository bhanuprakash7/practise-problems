package trees;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;


public class TreeSize {
	public static void main(String[] args) {
		Node node=new Node(1);
		node.left=new Node(2);
		node.left.left=new Node(3);
		node.left.right=new Node(4);
		node.right=new Node(5);
		node.left.right.left=new Node(7);
		node.right.right=new Node(6);
		/*System.out.println(countNodes(node));
		System.out.println(leafNode(node));
		boundaryTraversal(node);*/
		mirrorTree(node);
	}
	static int count=0;
	/*public static void countNodes(Node root){
		
		countNodes(root,count);
		System.out.println(count);
	}*/
	public static int countNodes(Node root){
		/*int count=0;
		Queue<Node> q=new LinkedList<Node>();
		q.add(root);
		
		while(q.size()>0){
			Node node=q.poll();
			count++;
			if(node.left!=null){
				q.add(node.left);
			}
			if(node.right!=null){
				q.add(node.right);
			}
		}
		System.out.println(count);*/
		if(root==null){
			return 0;
		}
		else{
			return countNodes(root.left)+countNodes(root.right)+1;
		}
		
	}
	public static int leafNode(Node root){
		if(root==null){
			return 0;
		}
		if(root.left==null&&root.right==null){
			return 1;
		}
		
			return leafNode(root.left)+ leafNode(root.right);
		
	}
	public static void boundaryTraversal(Node root){
		Set<Integer> set=new LinkedHashSet<Integer>();
		Node node=root;
		while(node!=null){
			set.add(node.data);
			node=node.left;
		}
		findLeafs(root,set);
		/*Queue<Node> queue=new LinkedList<Node>();
		Node node1=root;
		queue.add(node1);
		while(queue.size()>0){
			Node getNode=queue.poll();
			if(getNode.left==null&&getNode.right==null){
				set.add(getNode.data);
			}
			if(getNode.left!=null){
				queue.add(getNode.left);
			}
			if(getNode.right!=null){
				queue.add(getNode.right);
			}
			
		}*/
		Stack<Integer> s=new Stack<Integer>();
		while(root!=null){
			s.add(root.data);
			root=root.right;
		}
		while(s.size()>0){
			set.add(s.pop());
		}
		set.forEach(data->System.out.print(data));
	}
	public static void 	findLeafs(Node root,Set<Integer> set){
		if(root==null){
			return;
		}
		if(root.left==null&&root.right==null){
			set.add(root.data);
		}
		if(root.left!=null){
			findLeafs(root.left,set);
		}
		if(root.right!=null){
			findLeafs(root.right,set);
		}
	}
	public static void mirrorTree(Node node){
		if(node==null){
			return;
		}
		else{
			mirrorTree(node.left);
			mirrorTree(node.right);
			Node temp=node.left;
			node.left=node.right;
			node.right=temp;
		}
		
		
	}
}
