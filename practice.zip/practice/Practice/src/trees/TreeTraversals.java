package trees;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.TreeMap;

class Node{
	int data;
	Node left;
	Node right;
	public Node(int data){
		this.data=data;
		this.left=null;
		this.right=null;
	}
}
public class TreeTraversals 
{
	public static void main(String[] args) {
		/*Node node=new Node(1);
		node.left=new Node(2);
		node.left.left=new Node(3);
		node.left.right=new Node(4);
		node.left.right.left=new Node(7);
		node.right=new Node(5);
		node.right.right=new Node(6);*/
		/*inOrderTraversal(node);
		preOrderTraversal(node);
		postOrderTraversal(node);*/
		/*Node node=new Node(1);
		node.left=new Node(2);
		node.left.left=new Node(4);
		node.left.right=new Node(5);
		node.right=new Node(3);
		node.right.left=new Node(6);
		node.right.left.right=new Node(8);
		node.right.right=new Node(7);*/
		Node node=new Node(1);
		node.left=new Node(2);
		node.right=new Node(3);
		node.left.left=new Node(4);
		node.left.right=new Node(5);
		node.left.right.left=new Node(13);
		node.right.left=new Node(6);
		node.right.left.left=new Node(15);
		node.right.left.left.right=new Node(16);
		node.right.right=new Node(7);
		node.right.right.right=new Node(9);
		node.right.left.right=new Node(8);
		node.right.right.left=new Node(10);
		node.right.right.left.right=new Node(11);
		node.right.right.left.right.right=new Node(12);
		node.right.right.left.right.right.left=new Node(17);
		node.right.right.left.right.right.left.left=new Node(18);
		//verticalOrderTraversal(node);
		//topView(node);
		//bottomView(node);
		//leftView(node);
		diagonalTraversal(node);
	}
	public static void inOrderTraversal(Node root){
		if(root==null){
			return;
		}
		Stack<Node> stack=new Stack<Node>();
		Node node=root;
		while(stack.size()>0||node!=null){
			if(node==null){
				node=stack.pop();
				System.out.print(node.data+", ");
				node=node.right;
			}
			else{
				stack.add(node);
				node=node.left;
			}
		}
		System.out.println();
	}
	public static void preOrderTraversal(Node root){
		if(root==null){
			return;
		}
		Stack<Node> stack=new Stack<Node>();
		Node node=root;
		while(stack.size()>0||node!=null){
			if(node==null){
				node=stack.pop();
				node=node.right;
			}
			else{
				System.out.print(node.data+", ");
				stack.add(node);
				node=node.left;
			}
		}
		System.out.println();
	}
	public static void postOrderTraversal(Node root){
		if(root==null){
			return;
		}
		Stack<Node> stack1=new Stack<Node>();
		Stack<Node> stack2=new Stack<Node>();
		Node node=root;
		while(stack1.size()>0||node!=null){
			if(node==null){
				node=stack1.pop();
				node=node.left;
			}
			else{
				stack1.add(node);
				stack2.add(node);
				node=node.right;
			}
		}
		while(stack2.size()>0){
			System.out.print(stack2.pop().data+", ");
			
		}
		System.out.println();
	}
	public static void verticalOrderTraversal(Node root){
		if(root==null){
			return;
		}
		Map<Integer,List<Integer>> map=new TreeMap<Integer,List<Integer>>();
		
		verticalOrderTraversal(root,0,map);
		map.keySet().stream().forEach(k->{
			ArrayList<Integer> a=(ArrayList<Integer>) map.get(k);
			a.forEach(ele->System.out.print(ele));
			System.out.println();
		});
		System.out.println();
		
	}
	public static void verticalOrderTraversal(Node root,int hd,Map<Integer,List<Integer>> map){
		if(root==null){
			return;
		}
		if(!map.containsKey(hd)){
			
			map.put(hd, new ArrayList<Integer>(){{
				add(root.data);
			}});
		}
		else{
			List<Integer> l=map.get(hd);
			l.add(root.data);
		}
		verticalOrderTraversal(root.left,hd-1,map);
		verticalOrderTraversal(root.right,hd+1,map);
	}
	public static void topView(Node root){
		if(root==null){
			return;
		}
		Map<Integer,Integer> map=new TreeMap<Integer,Integer>();
		
		topView(root,0,map);
		map.keySet().stream().forEach(k->{
			
			System.out.print(map.get(k)+" ");
			
		});
		System.out.println();
		
	}
	public static void topView(Node root,int hd,Map<Integer,Integer> map){
		if(root==null){
			return;
		}
		if(!map.containsKey(hd)){
			
			map.put(hd, root.data);
				
			
		}
		topView(root.left,hd-1,map);
		topView(root.right,hd+1,map);
	}
	public static void bottomView(Node root){
		if(root==null){
			return;
		}
		Map<Integer,Integer> map=new TreeMap<Integer,Integer>();
		
		bottomView(root,0,map);
		map.keySet().stream().forEach(k->{
			
			System.out.print(map.get(k)+" ");
			
		});	
		System.out.println();
		
	}
	public static void bottomView(Node root,int hd,Map<Integer,Integer> map){
		if(root==null){
			return;
		}
		
			
		map.put(hd, root.data);
		
		bottomView(root.left,hd-1,map);
		bottomView(root.right,hd+1,map);
	}
	public static void leftView(Node root){
		if(root==null){
			return;
		}
		Map<Integer,Integer> map=new TreeMap<Integer,Integer>();
		
		leftView(root,0,map);
		map.keySet().stream().forEach(k->{
			
			System.out.print(map.get(k)+" ");
			
		});	
		System.out.println();
		
	}
	public static void leftView(Node root,int hd,Map<Integer,Integer> map){
		if(root==null){
			return;
		}
		
		if(!map.containsKey(hd)){
			map.put(hd, root.data);
		}
		
		leftView(root.left,hd+1,map);
		leftView(root.right,hd+1,map);
	}
	public static void diagonalTraversal(Node root){
		Queue<Node> q1=new LinkedList<>();
		Queue<Node> q2=new LinkedList<>();
		Node node=root;
		q1.add(node);
		diagonalTraversal(q1,q2);
	}
	public static void diagonalTraversal(Queue<Node> q1,Queue<Node> q2){
		while(q1.size()>0){
			Node node=q1.poll();
			System.out.print(node.data+", ");
			if(node.left!=null){
				q2.add(node.left);
			}
			Node rightNode=node.right;
			while(rightNode!=null){
				if(rightNode.left!=null){
					q2.add(rightNode.left);
				}
				System.out.print(rightNode.data+", ");
				rightNode=rightNode.right;
			}
		}
		System.out.println();
		while(q2.size()>0){
			Node node=q2.poll();
			System.out.print(node.data+", ");
			if(node.left!=null){
				q1.add(node.left);
			}
			Node rightNode=node.right;
			while(rightNode!=null){
				if(rightNode.left!=null){
					q1.add(rightNode.left);
				}
				System.out.print(rightNode.data+", ");
				rightNode=rightNode.right;
			}
		}
		System.out.println();
		if(q1.size()>0){
			diagonalTraversal(q1,q2);
		}
	}
}
