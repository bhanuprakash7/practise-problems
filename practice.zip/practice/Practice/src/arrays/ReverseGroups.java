package arrays;

import java.util.ArrayList;
import java.util.Stack;

public class ReverseGroups 
{
	 public static ArrayList<Integer> reverseInGroups(ArrayList<Integer> mv, int n, int k) {
	        // add your code here
		 
	      for(int i=0;i<n;i+=k){
	    	  int l=i;
	    	  int r=Math.min(i+k-1, n-1);
	    	  while(l<r){
	    		 int t=mv.get(l);
	    		 mv.set(l,mv.get(r));
	    		 mv.set(r, t);
	    		 l++;
	    		 r--;
	    	  }
	      }
	        
	       return mv; 
	    }
	 static ArrayList<Integer> leaders(int arr[], int n){
	        
	       Stack<Integer> s=new Stack<Integer>();
	       int min=Integer.MIN_VALUE;
	       for(int i=n-1;i>-1;i--){
	           if(arr[i]>=min){
	               min=arr[i];
	               s.push(min);
	           }
	       }
	     
	     return new ArrayList<Integer>().addAll(s);
	    }
	 public static void convertToWave(int arr[], int n){
	        
	        // Your code here
	        for(int i=0;i<n-1;i+=2){
	            int t=arr[i];
	            arr[i]=arr[i+1];
	            arr[i+1]=t;
	        }
	        
	    }
	 public static void main(String[] args) {
		 /*ArrayList<Integer> al=new ArrayList<Integer>();
		 al.add(1);
		 al.add(2);
		 al.add(3);
		 al.add(4);
		 al.add(5);
		 al.add(6);
		 al.add(7);
		 al.add(8);
		 ArrayList<Integer> a2= reverseInGroups(al,8,3);
		 for(Integer i:a2){
			 System.out.print(i);
		 }*/
		 int[] c={1,2,3,4,5};
		 convertToWave(c,5);
		 INT M=iNTEGER.m
		 Stack<Integer> s=new Stack<Integer>();
		 
	}
}
