import java.util.ArrayList;
import java.util.List;


public class Permutation 
{
	List<String> list=new ArrayList<String>();
	public static void swap(char c[],int i,int j){
		char t=c[i];
		c[i]=c[j];
		c[j]=t;
	}
	public static void permutate(char[] c,int start,int end){
		if(start==end-1){
			String s="";
			for(int i=0;i<c.length;i++){
				s+=c[i];
			}
			System.out.println(s);
			return;
		}
		else{
			for(int i=start;i<end;i++){
				swap(c,start,i);
				permutate(c,start+1,end);
				swap(c,start,i);
			}
		}
	}
	public static void main(String[] args) {
		String s="aabc";
		char[] c=new char[s.length()];
		for(int i=0;i<c.length;i++){
			c[i]=s.charAt(i);
		}
		permutate(c,0,c.length);
	}
}
