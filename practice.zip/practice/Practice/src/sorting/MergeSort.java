package sorting;

public class MergeSort 
{
	
	public static void mergeSort(int[] a,int i, int j,int[] temp){
		if(i>=j){
			return;
		}
		int mid=(i+j)/2;
		mergeSort(a,i,mid,temp);
		mergeSort(a,mid+1,j,temp);
		merge(a,i,j,temp);
		
	}
	public static void merge(int[] a,int leftStart, int rightEnd, int[] temp){
		int leftEnd=(leftStart+rightEnd)/2;
		int rightStart=leftEnd+1;
		int index=leftStart;
		int left=leftStart;
		int right=rightStart;
		int size=rightEnd-leftStart+1;
		while(leftStart<=leftEnd&&rightStart<=rightEnd){
			if(a[leftStart]<=a[rightStart]){
				temp[index++]=a[leftStart++];
			}
			else{
				temp[index++]=a[rightStart++];
			}
		}
		while(leftStart<=leftEnd){
			temp[index++]=a[leftStart++];
		}
		while(rightStart<=rightEnd){
			temp[index++]=a[rightStart++];
		}
		for(int i=left;i<size+left;i++){
			a[i]=temp[i];
		}
	}
	public static void main(String[] args) {
		int[] a={2,5,3,6,8,7,9,1};
		int []temp=new int[a.length];
		mergeSort(a,0,a.length-1,temp);
		for(int i:temp){
			System.out.print(i+" ");
		}
	}
}
