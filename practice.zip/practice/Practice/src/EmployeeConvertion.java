import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class Employee{
	int empid;
	String name;
	long salary;
	public Employee(int empid, String name, long salary) {
		super();
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary="
				+ salary + "]";
	}
	
}

public class EmployeeConvertion {
	public static void main(String[] args) {
		
		List<Employee> emp=Arrays.asList(
				new Employee(1,"bhanu",30000),
				new Employee(2,"prakash",40000),
				new Employee(3,"raju",50000)
				);
		//List<Employee> newEmp=emp.stream().map(x->{x.setSalary(x.getSalary()*2);return x;}).collect(Collectors.toList());
		
		List<Employee> newEmp=emp.stream().map(x->{x.setSalary(x.salary*2);return x;}).collect(Collectors.toList());
		
		
		/*List<Object> newEmp=emp.stream().map(x->{
			Employee e=new Employee(x.getEmpid(),x.getName(),x.getSalary()*2);
			return e;
		}).collect(Collectors.toList());*/
		System.out.println(newEmp);
	}
}
