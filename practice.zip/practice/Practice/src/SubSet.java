
public class SubSet
{
	public static void main(String[] args) {
		
	}
}
