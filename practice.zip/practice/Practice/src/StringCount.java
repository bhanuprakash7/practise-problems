
public class StringCount 
{
	public static void main(String[] args) {
		String s="12345";
		int s1=0;
		for(int i=0;i<s.length();i++){
			s1+=Integer.parseInt(""+s.charAt(i));
		}
		System.out.println(s1);
	}
}
