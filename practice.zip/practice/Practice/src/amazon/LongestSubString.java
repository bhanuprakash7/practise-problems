package amazon;
import java.util.HashMap;
import java.util.Map;


public class LongestSubString 
{
	public static int max=Integer.MIN_VALUE;
	public static String subStr(int l,String s){
		int i=l+1;
		StringBuilder s1=new StringBuilder("");
		Map<Character,Integer> m=new HashMap<Character,Integer>();
		m.put(s.charAt(l), 1);
		s1.append(s.charAt(l));
		if(i<s.length()){
			while(!m.containsKey(s.charAt(i))){
				m.put(s.charAt(i), 1);
				s1.append(s.charAt(i));
				i++;
				if(i==s.length()){
					break;
				}
			}
		}
		if(s1.length()>max){
			max=s1.length();
			return s1.toString();
		}
		else
		{
			return "1";
		}
		
	}
	public static void main(String[] args) {
		String s="ABCA";
		//Map<Character,Integer> m=new HashMap<Character, Integer>();
		int l=0;
		String s1="";
		
		int k=0;
		
		for(int i=0;i<s.length();i++){
			String s2=subStr(i,s);
			if(!s2.equals("1")){
				s1=s2;
			}
		}
		
		System.out.println(s1);
		
	}
}
