package amazon;

import java.util.Scanner;

public class MatrixDiagonal 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		while(t-->0){
			int a=sc.nextInt();
			int b=a;
			int[][] arr=new int[a][b];
			for(int i=0;i<a;i++){
				for(int j=0;j<b;j++){
					arr[i][j]=sc.nextInt();
				}
			}
			for(int j=0;j<b;j++){
				int k=0;
				int l=j;
				if(k==l){
					System.out.print(arr[k][l]);
				}
				else{
					int c=k;
					int d=l;
					while(true){
						if(k==d&&c==l){
							System.out.print(arr[k][l]);
							break;
						}
						else{
							System.out.print(arr[k][l]);
							k++;
							l--;
						}
					}
				}
			}
			for(int i=0;i<a;i++){
				int k=i;
				int l=b-1;
				if(k==l){
					System.out.print(arr[k][l]);
				}
				else{
					int c=k;
					int d=l;
					while(true){
						if(k==d&&c==l){
							System.out.print(arr[k][l]);
							break;
						}
						else{
							System.out.print(arr[k][l]);
							k++;
							l--;
						}
					}
				}
			}
			System.out.println();
		}
	}
}
