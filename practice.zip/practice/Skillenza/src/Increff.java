import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;


public class Increff 
{
	public static void doProcess(int[] arr,List<Integer> l,int n){
		if(n==1){
			System.out.println(1);
			return;
		}
		Set<Integer> s=new TreeSet<Integer>();
		s.addAll(l);
		int[] array=s.stream().mapToInt(Integer::intValue).toArray();
		int[] a=new int[n];
		
		/*for(Integer i:a){
			i=new Integer(0);
		}*/
		int N=array.length;
		for(int j=0;j<N;j++){
			for(int i=0;i<n;i++){
				if(array[j]==arr[i]){
					if(i==0){
						if(arr[i]<arr[i+1]){
							if(a[i]==0){
								a[i]++;
								a[i+1]=a[i]+1;
							}
							else{
								a[i+1]=a[i]+1;
							}
						}
					}
					else if(i==n-1){
						if(arr[i]<arr[i-1]){
							if(a[i]==0){
								a[i]++;
								a[i-1]=a[i]+1;
							}
							else{
								a[i-1]=a[i]+1;
							}
						}
					}
					else{
						if(arr[i]<arr[i-1]&&arr[i]<arr[i+1]){
							if(a[i]==0){
								a[i]++;
								a[i-1]=a[i]+1;
								a[i+1]=a[i]+1;
							}
							else{
								a[i-1]=a[i]+1;
								a[i+1]=a[i]+1;
							}
						}
						else if(arr[i]<arr[i-1]&&arr[i]>=arr[i+1]){
							if(a[i]==0){
								a[i]++;
								if(a[i-1]<=a[i]){
									a[i-1]=a[i]+1;
								}
								
							}
							else{
								a[i-1]=a[i]+1;
							}
						}
						else if(arr[i]>=arr[i-1]&&arr[i]<arr[i+1]){
							if(a[i]==0){
								a[i]++;
								if(a[i+1]<=a[i]){
									a[i+1]=a[i]+1;
								}
								
							}
							else{
								a[i+1]=a[i]+1;
							}
						}
					}
				}
				
			}
		}
		for(int i=0;i<n;i++){
			if(a[i]==0){
				a[i]=1;
			}
		}
		for(Integer i:a){
			System.out.print(i+" ");
		}
		System.out.println();
	}
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		while(t-->0){
			int n=sc.nextInt();
			int [] arr=new int[n];
			List<Integer> l=new ArrayList<Integer>();
			for(int i=0;i<n;i++){
				arr[i]=sc.nextInt();
				l.add(arr[i]);
			}
			
			doProcess(arr,l,n);
		}
	}
}
