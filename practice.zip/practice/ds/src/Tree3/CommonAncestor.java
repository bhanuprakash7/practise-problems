package Tree3;

import java.util.*;
import java.io.*;

class Node {
    Node left;
    Node right;
    int data;
    
    Node(int data) {
        this.data = data;
        left = null;
        right = null;
    }
}

public class CommonAncestor {

	/*
    class Node 
    	int data;
    	Node left;
    	Node right;
	*/
	public static Node lc(Node root, int v1){
		if(root.left==null&&root.right==null){
			return null;
		}
		if(root.left!=null){
			if(root.left.data==v1){
				return root;
			}
		}
		if(root.right!=null){
			if(root.right.data==v1){
				return root;
			}
		}
		
		if(root.left!=null||root.right!=null){
			Node n1=lc(root.left,v1);
			Node n2=null;
			if(n1==null)
				n2=lc(root.right,v1);
			if(n1!=null&&n2==null){
				return n1;
			}
			else if(n2!=null&&n1==null){
				return n2;
			}
			
			
			
		}
		return null;
	}
	public static Node lca(Node root, int v1, int v2) {
      	// Write your code here.
		/*Node n1=null,n2=null;
		if(root.data==v1||root.data==v2){
			return root;
		}
			n1=lc(root,v1);
		
		
			n2=lc(root,v2);
		
		
		if(n1!=n2){
			return root;
		}
		if(n1==n2){
			return n1;
		}
		return n1==null?n2:n1;*/
		if(root.data==v1||root.data==v2){
			return root;
		}
		Node node=null;
		if(root.data>v1&&root.data>v2){
			node=lca(root.left,v1,v2);
		}
		else if(root.data<v1&&root.data<v2){
			node=lca(root.right,v1,v2);
		}
		else{
			return root;
		}
		return node;
		
    }

	public static Node insert(Node root, int data) {
        if(root == null) {
            return new Node(data);
        } else {
            Node cur;
            if(data <= root.data) {
                cur = insert(root.left, data);
                root.left = cur;
            } else {
                cur = insert(root.right, data);
                root.right = cur;
            }
            return root;
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int t = scan.nextInt();
        Node root = null;
        while(t-- > 0) {
            int data = scan.nextInt();
            root = insert(root, data);
        }
        int v1 = scan.nextInt();
      	int v2 = scan.nextInt();
        scan.close();
        Node ans = lca(root,v1,v2);
        System.out.println(ans.data);
    }	
}