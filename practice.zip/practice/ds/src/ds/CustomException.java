package ds;

public class CustomException 
{
	public int doException(){
		try{
			int i=0;
			int val=100/0;
			return 10;
		}
		catch(ArithmeticException e){
			return 20;
		}
		finally{
			System.out.println("final");
			
		}
		
	}
	public static void main(String[] args) {
		CustomException c=new CustomException();
		
			System.out.println(c.doException());
		
	}
}
