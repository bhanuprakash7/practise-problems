package ds;

class Node{
	int value;
	Node next;
	
	public Node(int value){
		this.value=value;
		this.next=null;
	}
}

public class LinkedListImplementation {
	static Node n=new  
}
