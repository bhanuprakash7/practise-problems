package ds;
class A{
	public void m1(){
		System.out.println("A m1");
	}
	public void m2(){
		System.out.println("A m2");
	}
}
public class B extends A{
	public void m2(){
		System.out.println("B m2");
	}
	public void m3(){
		System.out.println("B m3");
	}
	public static void main(String[] args) {
		A a1=new A();
		A a2=new B();
		B b1=new B();
		B b2=(B) a2;
		
		a1.m1();
		a1.m2();
		a2.m1();
		a2.m2();
		b1.m1();
		b1.m2();
		b1.m3();
		b2.m1();
		b2.m2();
		b2.m3();
		
	}
}
