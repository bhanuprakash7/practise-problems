package ds;

public class MethodOverloading 
{
	public int add(int a, int b){
		return a+b;
	}
	
	public double add(double a, double b){
		return a+b;
	}
	
	public static void main(String args[]){
		MethodOverloading m=new MethodOverloading();
		m.add(1.1, 2);
		m.add(4, 2);
	}
}
