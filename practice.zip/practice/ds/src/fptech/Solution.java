package fptech;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;


class Node{
	int data;
	int level;
	ArrayList<Node> nextNodes;
	public Node(){
		this.data=0;
		this.level=0;
		this.nextNodes=new ArrayList<Node>();
	}
}
public class Solution 
{
	public static void searchForIndex(Map<Integer,Integer> m){
		int[] i={Integer.MIN_VALUE};
		List<Integer> al=new ArrayList<Integer>();
		m.forEach((key,value)->{
			if(value>i[0]){
				i[0]=value;
			}
		});
		m.forEach((key,value)->{
			if(value==i[0]){
				al.add(key);
			}
		});
		al.stream().sorted();
		System.out.println(al.get(0));
	}
	public static boolean searchToAddNode(Node node,int n,int a,Map<Integer,Integer> m){
		List<Node> ar=node.nextNodes;;
		if(node.data==n){
			Node next=new Node();
			next.data=a;
			next.level=node.level+1;
			node.nextNodes.add(next);
			m.put(next.data, next.level);
			return true;
		}
		boolean[] b={false};
		ar.forEach((nodeData)->{
			if(!b[0]){
				b[0]=searchToAddNode(nodeData,n,a,m);
			}
		});
		
		return b[0];
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int t=sc.nextInt();
		while(t-->0){
			Node node=null;
			int n=sc.nextInt();
			Map<Integer,Integer> m=new HashMap<Integer,Integer>();
			for(int i=0;i<n-1;i++){
				int a=sc.nextInt();
				int b=sc.nextInt();
				if(node==null){
					node=new Node();
					node.data=a;
					Node next=new Node();
					next.data=b;
					next.level=node.level+1;
					node.nextNodes.add(next);
					m.put(node.data,node.level);
					m.put(next.data, next.level);
				}
				else{	
					searchToAddNode(node,a,b,m);	
				}
			}
			int find=sc.nextInt();
			searchForIndex(m);
		}
		sc.close();
	}
}
