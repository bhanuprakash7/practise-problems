package huffman;
import java.io.ObjectInputStream.GetField;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Set;

class Node{
	char character;
	int data;
	Node left;
	Node right;
	public Node(){
		
	}
	public Node(char character,int data){
		this.character=character;
		this.data=data;
	}
	public Node(int data){
		this.data=data;
	}
}
class NodeComparator implements Comparator<Node>{

	@Override
	public int compare(Node n1, Node n2) {
		// TODO Auto-generated method stub
		if (n1.data>n2.data) 
            return 1; 
        else if (n1.data < n2.data) 
            return -1; 
                        return 0; 
        } 	
}

public class Huffman 
{
	static Map<Character,String> cm=new HashMap<Character,String>();
	static StringBuilder str=new StringBuilder("");
	static StringBuilder outdata=new StringBuilder("");
	public static void encode(Node node){
		
		
		if(node.left!=null){
			traverse(node.left,str.append(0));
		}
		if(node.right!=null){
			traverse(node.right,str.append(1));
		}
	}
	
	/*public static void decode(String s,Node root){
		int i=0; 
		if(s.charAt(i)=='0'){
			i=doDecode(root.left,i++,s);
			if(i==0){
				decode(s,root);
			}
		}
		
		if(s.charAt(i)=='1'){
			doDecode(root.right,i++,s);
		}
	}*/
	
	public static void doDecode(Node node,int i,String s){
		
		
		if(node.left==null&&node.right==null){
			outdata.append(node.character);
			node=rootNode;
		}
		
		if(s.length()>i){
			if(s.charAt(i)=='0')
				doDecode(node.left,++i,s);
			else if(s.charAt(i)=='1'){
				doDecode(node.right,++i,s);
			}
			
		}
		else{
			return;
		}
		
	}
	
	public static void traverse(Node node,StringBuilder s){
		if(node.left==null&&node.right==null){
			if(!cm.containsKey(node.character)){
				cm.put(node.character, s.toString());
			}
			s=new StringBuilder(s.substring(0, s.length()-1));
			str=s;
		}
		if(node.left!=null){
			traverse(node.left,str.append(0));
		}
		if(node.right!=null){
			traverse(node.right,str.append(1));
		}
	}
	static Node rootNode=null;
	public static void buildHuffmanTree(String s){
		Map<Character,Integer> m=new HashMap<Character,Integer>();
		for(int i=0;i<s.length();i++){
			if(!m.containsKey(s.charAt(i))){
				int val=1;
				m.put(s.charAt(i), val);
			}
			else{
				int val=m.get(s.charAt(i));
				m.replace(s.charAt(i),val , ++val);
			}
		}
		PriorityQueue<Node> p = new PriorityQueue<Node>(new NodeComparator());
		for(Map.Entry<Character, Integer> m1:m.entrySet()){
			p.add(new Node(m1.getKey(), m1.getValue()));
		}
		Node root=null;
		while(!p.isEmpty()){
			
			Node a=p.poll();
			Node b=p.poll();
			int sum=a.data+b.data;
			Node node=new Node();
			node.data=sum;
			if(a.data<=b.data){
				node.left=a;
				node.right=b;
			}
			else{
				node.left=b;
				node.right=a;
			}
			p.add(node);
			if(p.size()==1){
				root=node;
				break;
			}
		}
		
		encode(root);
		rootNode=root;
		for(Map.Entry<Character,String> c:cm.entrySet()){
			System.out.println(c.getKey()+" "+c.getValue());
		}
		/*Iterator itr=p.iterator();
		while(itr.hasNext()){
			Node n=(Node) itr.next();
			System.out.println(n.character+" "+n.data);
		}*/
		
		System.out.println(outdata);
	}
	static StringBuffer stri=new StringBuffer("");
	public static void main(String[] args) {
		String s="aabacdab";
		buildHuffmanTree(s);
		for(int i=0;i<s.length();i++){
			if(cm.containsKey(s.charAt(i))){
				stri.append(cm.get(s.charAt(i)));
				System.out.print(cm.get(s.charAt(i)));
			}
			
		}
		doDecode(rootNode,0,stri.toString());
		System.out.println(outdata);
	}
}
