import java.util.*;
import java.io.*;

import tree2.Node;

class Node {
    Node left;
    Node right;
    int data;
    
    Node(int data) {
        this.data = data;
        left = null;
        right = null;
    }
}

public class Height {

	/*
    class Node 
    	int data;
    	Node left;
    	Node right;
	*/
	static int lh=1,rh=1;
	public static void lHeight(Node node){
		if(node.left!=null){
			lHeight(node.left);
		}
		if(node.right!=null){
			lHeight(node.right);
		}
		if(node.left!=null||node.right!=null){
			lh++;
		}
	}
	public static void rHeight(Node node){
		if(node.left!=null){
			rHeight(node.left);
		}
		if(node.right!=null){
			rHeight(node.right);
		}
		if(node.left!=null||node.right!=null){
			rh++;
		}
	}
	public static int height(Node root) {
		
		if(root.left==null&&root.right==null){
			return 0;
		}
		if(root.left!=null){
			lHeight(root.left);
		}
		if(root.right!=null){
			rHeight(root.right);
		}
		return lh>rh?lh:rh;
      	// Write your code here.
    }
    
	public static Node insert(Node root, int data) {
        if(root == null) {
            return new Node(data);
        } else {
            Node cur;
            if(data <= root.data) {
                cur = insert(root.left, data);
                root.left = cur;
            } else {
                cur = insert(root.right, data);
                root.right = cur;
            }
            return root;
        }
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int t = scan.nextInt();
        Node root = null;
        while(t-- > 0) {
            int data = scan.nextInt();
            root = insert(root, data);
        }
        scan.close();
        int height = height(root);
        System.out.println(height);
    }	
}