package Matrix;

import java.util.Scanner;

public class Solution 
{
	public static boolean cx(char a){
		return a=='x'?true:false;
	}
	public static boolean co(char a){
		return a=='o'?true:false;
	}
	public static void st(char[][] a,int k,int l,int p){
		int x=0,o=0,K=k;
		for(int i=0;i<l;i++){
			for(int j=0;j<=p-K;j++){
				int c=j+1;
				k=k-1;
				while(k>0)
				{
					if(a[i][j]=='x'){
						boolean b=cx(a[i][c]);
						if(!b)
							break;
						k--;
						c++;
						if(k==0){
							x++;
							break;
						}	
					}
					else{
						boolean b=co(a[i][c]);
						if(!b)
							break;
						k--;
						c++;
						if(k==0){
							o++;
							break;
						}
					}
				}
				k=K;
			}
		}
		for(int i=0;i<=l-K;i++){
			for(int j=0;j<=p-K;j++){
				int d=i+1;
				int c=j+1;
				k=k-1;
				while(k>0)
				{
					if(a[i][j]=='x'){
						boolean b=cx(a[d][c]);
						if(!b)
							break;
						k--;
						d++;
						c++;
						if(k==0){
							x++;
							break;
						}
					}
					else{
						boolean b=co(a[d][c]);
						if(!b)
							break;
						k--;
						d++;
						c++;
						if(k==0){
							o++;
							break;
						}
					}	
				}
				k=K;
			}	
		}
		for(int j=0;j<p;j++){
			for(int i=0;i<=l-K;i++){
				int c=i+1;
				k=k-1;
				while(k>0)
				{
					if(a[i][j]=='x'){
						boolean b=cx(a[c][j]);
						if(!b)
							break;
						k--;
						c++;
						if(k==0){
							x++;
							break;
						}
					}
					else{
						boolean b=co(a[c][j]);
						if(!b)
							break;
						k--;
						c++;
						if(k==0){
							o++;
							break;
						}
					}
				}
				k=K;
			}
		}
		for(int i=0;i<=l-K;i++){
			for(int j=p-1;j>=K-1;j--){
				int c=j-1;
				int d=i+1;
				k=k-1;
				while(k>0)
				{
					if(a[i][j]=='x'){
						boolean b=cx(a[d][c]);
						if(!b)
							break;
						k--;
						c--;
						d++;
						if(k==0){
							x++;
							break;
						}
					}
					else{
						boolean b=co(a[d][c]);
						if(!b)
							break;
						k--;
						d++;
						c--;
						if(k==0){
							o++;
							break;
						}
					}
				}
				k=K;
			}
		}
		System.out.println(x+" "+o);
	}
	public static void main(String[] args){
		Scanner s=new Scanner(System.in);		
		int t=s.nextInt();
		while(t-->0){
			int m=s.nextInt();
			int n=s.nextInt();
			int k=s.nextInt();
			char[][] a=new char[m][n];
			for(int i=0;i<m;i++){
				for(int j=0;j<n;j++){
					a[i][j]=s.next().charAt(0);
				}
			}
			st(a,k,m,n);
		}
	}
}
