package Matrix;

import java.util.Scanner;

public class Demo 
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		while(t-->0){
			int m=sc.nextInt();
			int n=sc.nextInt();
			int k=sc.nextInt();
			System.out.println(t+" "+m+" "+n+" "+k);
			char[][] arr=new char[m][n];
			for(int i=0;i<m;i++){
				
				
				for(int j=0;j<n;j++){
					
					arr[i][j]=sc.next().charAt(0);
				}
			}
				
		
			for(int i=0;i<3;i++){
				
				for(int j=0;j<3;j++){
					
					System.out.println(arr[i][j]);
				}
		
				
		}
			
		}}
}
