package Matrix;

public class Demo1 {
	public static void main(String[] args) {
		boolean b=true;
		if(!b)
			System.out.println("abc");
		    System.out.println("def");
		    
		System.out.println("no");    
	}
}
