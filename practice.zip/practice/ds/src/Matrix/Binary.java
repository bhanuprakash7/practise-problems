package Matrix;

import java.math.BigInteger;
import java.util.Scanner;

public class Binary 
{
	public static int[] c(String s){
		int[] a={0,0};
		for(int i=0;i<s.length();i++){
			if(s.charAt(i)=='0'){
				a[0]++;
			}
			else{
				a[1]++;
			}
		}
		return a;
	}
	
	public static void su(StringBuilder s,int n){
		String sub="";
		int o=0,z=0;
		for(int i=0;i<n;i++){
			for(int j=i+1;j<=n;j++){
				sub=s.substring(i, j);
				int[] zo=c(sub);
				if(zo[0]%2!=0)
					z++;
				if(zo[1]%2!=0)
					o++;
			}
		}
		System.out.println(z+" "+o);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		BigInteger z=BigInteger.ZERO;
		while(t-->0){
			BigInteger n=new BigInteger(sc.next());
			if(n.equals(z)){
				System.out.println("1 0");
			}
			else{
				StringBuilder s=new StringBuilder("");
				BigInteger tw=new BigInteger("2");
				while(!n.equals(z)){
					s.append(n.remainder(tw));
					n=n.divide(tw);	
				}
				StringBuilder u=new StringBuilder("");
				for(int i=s.length()-1;i>=0;i--){
					u.append(s.charAt(i));
				}
				su(u,u.length());
			}
		}	
	}
}
