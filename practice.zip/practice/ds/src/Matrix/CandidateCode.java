package Matrix;

import java.util.Scanner;

public class CandidateCode {
	public static void main(String[] args) {
		int a,i,j,count=0;
		Scanner s=new Scanner(System.in);
		a=s.nextInt();
		if(a<=10000 && a>0)
		{
			for(i=1;i<=a;i++)
			{
				for(j=1;j<=(2*i)-1;j++)
				{
		
				}
				while(j<=a)
				{
					count++;
					j++;
				}
			}
			System.out.println(count);
		}
	}
}
