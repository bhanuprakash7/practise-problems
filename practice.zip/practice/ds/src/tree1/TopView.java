package tree1;

import java.util.*;


class Node {
    Node left;
    Node right;
    int data;
    
    Node(int data) {
        this.data = data;
        left = null;
        right = null;
    }
}

public class TopView {

	/* 
    
    class Node 
    	int data;
    	Node left;
    	Node right;
	*/
//	public static void pl(Node node){
//		System.out.println(node.data);
//		if(node.left!=null){
//			pl(node.left);
//		}
//	}
//	public static void rl(Node node){
//		System.out.println(node.data);
//		if(node.right!=null){
//			pl(node.right);
//		}
//	}
	public static void topView(Node root) {
		class QueObj{
			Node node;
			int data;
			
			public QueObj(Node node,int data){
				this.node=node;
				this.data=data;
			}
		}
		Queue<QueObj> q=new LinkedList<QueObj>();
		q.add(new QueObj(root,0));
		Map<Integer,Node> m=new TreeMap<Integer,Node>();
		Node n=root;
		while(!q.isEmpty()){
			QueObj q1=q.peek();
			if(!m.containsKey(q1.data)){
				m.put(q1.data, q1.node);
			}
			QueObj q2=q.poll();
			Node r=q2.node;
			int hd=q2.data;
			if(r.left!=null){
				q.add(new QueObj(r.left,hd-1));
			}
			if(r.right!=null){
				q.add(new QueObj(r.right,hd+1));
			}
			
		}
		for(Map.Entry<Integer,Node> s:m.entrySet()){
			Node n1=s.getValue();
			System.out.print(n1.data+" ");
		}
		
    }

	public static Node insert(Node root, int data) {
        if(root == null) {
            return new Node(data);
        } else {
            Node cur;
            if(data <= root.data) {
                cur = insert(root.left, data);
                root.left = cur;
            } else {
                cur = insert(root.right, data);
                root.right = cur;
            }
            return root;
        }
    }

    public static void main(String[] args) {
    	Scanner scan = new Scanner(System.in);
        int t = scan.nextInt();
        Node root = null;
        while(t-- > 0) {
            int data = scan.nextInt();
            root = insert(root, data);
        }
        scan.close();
        topView(root);
	} 
        
    	
}